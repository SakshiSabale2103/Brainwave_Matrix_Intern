<!DOCTYPE html>
<html>
    <head>
    <meta name="veiwport" content="with=device-width, initial-scale=1.0">
    <title>NGO's Manaagement System- Home page</title>
    <link rel ="stylesheet" href="istyle.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,200;0,300;0,400;1,300;1,500&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,200;0,300;0,400;1,300;1,500&display=swap" rel="stylesheet">

     </head>
    <body>
        <section class="header">

      <nav>
            <a href="index.php"><img src = "images/logo2.png"; height=100px; width=150px;border="1"></a>
        <div class="nav-links">
          <ul>
              <li><a href="index.php">HOME</a></li>
              <li><a href="women.php">WOMEN EMPOWERMENT</a></li>
              <li><a href="child.php">CHILDREN</a></li>
              <li><a href="elderly.php">ELDERS</a></li>
              <li><a href="aspa.php">ASSOCIATES PARTNERS</a></li>
              <li><a href="about.html">CONTACT US</a></li>
              <li><a href="">USER</a>
                <div class="sub-menu">
                  <ul>
                    <li><a href="register.php">Register</a></li>
                    <li><a href="login.php">Login</a></li>
                    </ul>
                </div>
              </li>
          </ul>
        </div>
      </nav>
      <div class="text-box">
        <h1><i>Welcome To </i></h1>
        <h2><mark>HumanAngels</mark> NGO's Organization</h2>
        <p>It's not how much we give but how much love we put into giving</p>
        <a href="login.php" class="hero-btn"><b>Donate Now</b></a>
      </div>
</section>

<section class="info">
  <div class="row">
      <div class="info-col">
          <h3>Mission</h3>
          <p>We seek to build 'The Advantaged Soceity' by helping disadvantaged. We help disadvantaged by enhancing child education eradicating poverty, by empowering women, by dissimenting happiness in old-age home.</p>
      </div>
      <div class="info-col">
        <h3>Vision</h3>
        <p>'The Advantaged Soceity'</p>
    </div>
        <div class="info-col">
        <h3>Values</h3>

            <p>Accountability<br>
            Reliability<br>
            Cost-Effectivenes<br>
            Personal Service</p>


    </div>
  </div>

</section>
<section class="contact">
    <h1>Contact our Organization For more information</h1>
    <h3><a href="about.html" class="hero-btn">CONTACT US</a></h3>
</section>


       <section class="footer">
           <h4>About Us</h4>

       <p>"It is a donation platform for supporting differenr NGO'S across Maharashtra. These NGO'S work for upliftment and betterment of the children,women development, education,social awareness and other objectives."</p>
    <div class="icons">
    <i class="fa fa-facebook"></i>
    <i class="fa fa-Instagram"></i>
    <i class="fa fa-Linkedin"></i>
    <i class="fa fa-Twitter"></i>
</div>
</section>


    </body>
</html>
