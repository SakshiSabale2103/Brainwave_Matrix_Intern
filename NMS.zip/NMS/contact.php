<?php
	$name = $_POST['name'];
	$email = $_POST['email'];
	
	// Database connection
	$conn = new mysqli('localhost','root','','ngo');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into contact(name, email) values(?, ?, ?)");
		$stmt->bind_param("sssssi", $name, $email);
		$execval = $stmt->execute();
		echo $execval;
		echo "Your contact is successfully saved ...";
		$stmt->close();
		$conn->close();
	}
?>