<?php
echo "<script>alert('Wow! You Have Successfully logged in')</script>";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <style type="text/css">
    .body{
    text-align: center;
    margin-top: 200px;
    

}
.contact{
    margin: 100px auto;
    width: 80%;
    background-image: linear-gradient(rgba(75, 73, 73, 0.7),rgba(75, 73, 73, 0.7)),url(images/logout.jpg);
    background-position: center;
    background-size: cover;
    border-radius: 10px;
    text-align: center;
    padding:100px 0;
}
        

.contact h1{
    color: #fff;
    margin-top: 50px;
    padding: 0;
}
.hero-btn{
    display: inline-block;
    text-decoration: none;
    color:black;
    border: 2px solid rgb(27, 18, 18);
    padding: 12px 20px;
    font-size: 15px;
    background: transparent;
    position: relative;
    cursor: pointer;
}

.hero-btn:hover{
    border: 1px solid #f44336;
    background:  #f44336;
    transition: 1s;
}

        </style>
</head>
<body>
    <section class="body">
    <div class="contact">
   <h3> Welcome Donar </h3>
<p>Here you can logout from this page or you can donate for a NGO organizations</p>
        
    <a href="logout.php" class="hero-btn">Logout</a>&nbsp &nbsp &nbsp <a href="donation1.html" class="hero-btn">Donate now</a></h3>
    </div>
    </section>
</body>
</html>