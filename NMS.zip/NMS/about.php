<!DOCTYPE html>
<!-- Created By CodingLab - www.codinglabweb.com -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
   <title> Responsive Contact Us Form  | CodingLab </title>
    <link rel="stylesheet" href="aboutstyle.css">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
    
  <div class="container">
    <div class="content">
      <div class="left-side">
        <div class="address details">
          <i class="fas fa-map-marker-alt"></i>
          <div class="topic">Address</div>
          <div class="text-one">Nehru-Nagar, 411018</div>
          <div class="text-two">Pimpri-Pune 18</div>
        </div>
        <div class="phone details">
          <i class="fas fa-phone-alt"></i>
          <div class="topic">Phone</div>
          <div class="text-one">+9178 4189 7506</div>
          <div class="text-two">+9196 3434 5678</div>
        </div>
        <div class="email details">
          <i class="fas fa-envelope"></i>
          <div class="topic">Email</div>
          <div class="text-one">tirlapurrutika@gmail.com</div>
          <div class="text-two">info.tirlapurrutika@gmail.com</div>
        </div>
      </div>
      <div class="right-side">
        <div class="topic-text">Send us a message</div>

        <p>If you have any queries regarding our NGO and our Associate Partners then, you can send us message from here. It's our pleasure to help you.</p>
      <form action="contact.php" method="POST">
        <div class="input-box">
          <input type="text" name="name" placeholder="Enter your name">
        </div>
        <div class="input-box">
          <input type="text" name="email" placeholder="Enter your email">
        </div>
        <div class="input-box message-box">
          
        </div>
        <a href="" class="hero-btn">SEND NOW</a></h3>&nbsp&nbsp&nbsp&nbsp&nbsp<a href="index.php" class="hero-btn">BACK</a></h3>
    </div>
          
      </form>
     
    </div>
    </div>
  </div>
</body>
</html>
