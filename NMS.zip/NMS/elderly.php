<!DOCTYPE html>
<html>
    <head>
    <meta name="veiwport" content="with=device-width, initial-scale=1.0">
    <title>NGO's Manaagement System- Home page</title>
    <link rel ="stylesheet" href="eldstyle.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,200;0,300;0,400;1,300;1,500&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,200;0,300;0,400;1,300;1,500&display=swap" rel="stylesheet">

     </head>
    <body>
        <section class="header">
          <nav>
                <a href="index.php"><img src = "images/logo2.png"; height=100px; width=150px;border="1"></a>
            <div class="nav-links">
              <ul>
                <li><a href="index.php">HOME</a></li>
                <li><a href="women.php">WOMEN EMPOWERMENT</a></li>
                <li><a href="child.php">CHILDREN</a></li>
                <li><a href="elderly.php">ELDERS</a></li>
                <li><a href="aspa.php">ASSOCIATES PARTNERS</a></li>
                <li><a href="about.html">CONTACT US</a></li>
                <li><a href="">USER</a>
                    <div class="sub-menu">
                      <ul>
                        <li><a href="register.php">Register</a></li>
                        <li><a href="login.php">Login</a></li>
                        </ul>
                    </div>
                  </li>
              </ul>
            </div>
          </nav>
      <div class="text-box">
        <p>NGO WORKING FOR THE SENIOR CITIZENS </p>
      <h2>Let them never know what old age is! </h2><br>
      <a href="" class="hero-btn"><b>Donate Now</b></a><br>
    </div>
      <div class="rows">
        <div class="card">
          <div class="card-images pic1"></div>
          <a href="aspa.php">
          <h2>MANAVLOK</h2></a>
        </div>
      <div class="card">
        <div class="card-images pic2"></div>
        <a href="aspa.php">
        <h2>HELPAGEINDIA</h2></a>
      </div>
      <div class="card">
        <div class="card-images pic3"></div>
        <a href="aspa.php">
        <h2>DIGNITYFOUNDATION</h2></a>
      </div>
  </div>
  </section>
    <section class="heade">
      <div class="row">
        <div class="p1">
          <div class="img1">
          <img src = "images/old-age-ppl1.jpg"; height=300px; width=450px;border="1">
          <a href="https://youtu.be/gCa3Fwrox70"><img src = "images/play.png"; class="play-btn"></a>
          </div>
        </div>
        <div class="stat">
          <h2><mark>P</mark>eople live with dignity all their life and suddenly one day they are left with no choice but to beg to survive. In villages, many elderly are left alone after their children move to the cities in search of better livelihood. <h2>
        </div>
      </div>
     <div class="bro">
       <div class="sen">
       <h2><mark>"W</mark>hy would respect and care not be accorded to people who have contributed their quota to our nation, family and community, simply because they are <mark>old?”</mark> <h2>
     </div>
       <div class="pen">
         <div class="img3">
         <img src = "images/old-1.png"; height=400px; width=650px;border="1">
         </div>
       </div>
     </div>
     <div class="angel">
     <img src = "images/logo2.png"; height=100px; width=100px;>
     </div>
     </section>
     </body>
     </html>
