<?php
$_SERVER = "localhost";
$_USERNAME ="root";
$_PASSWORD ="";
$_DATABASE ="ngo";
 
$conn = mysqli_connect($_SERVER,$_USERNAME,$_PASSWORD,$_DATABASE);

if(!$conn) {
    die("<script>alert('Connection Failed.')</script>");

}
?>