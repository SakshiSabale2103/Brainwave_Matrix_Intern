<!DOCTYPE html>
<html>
    <head>
    <meta name="veiwport" content="with=device-width, initial-scale=1.0">
    <title>NGO's Manaagement System- Home page</title>
    <link rel ="stylesheet" href="assostyle.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,200;0,300;0,400;1,300;1,500&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,200;0,300;0,400;1,300;1,500&display=swap" rel="stylesheet">

     </head>
    <body>
        <section class="header">
          <nav>
                <a href="index.php"><img src = "images/logo2.png"; height=100px; width=150px;border="1"></a>
            <div class="nav-links">
              <ul>
                <li><a href="index.php">HOME</a></li>
                <li><a href="women.php">WOMEN EMPOWERMENT</a></li>
                <li><a href="child.php">CHILDREN</a></li>
                <li><a href="elderly.php">ELDERS</a></li>
                <li><a href="aspa.php">ASSOCIATES PARTNERS</a></li>
                <li><a href="about.html">CONTACT US</a></li>
                <li><a href="">USER</a>
                    <div class="sub-menu">
                      <ul>
                        <li><a href="register.php">Register</a></li>
                        <li><a href="login.php">Login</a></li>
                        </ul>
                    </div>
                  </li>
              </ul>
            </div>
          </nav>
      <div class="text-box">
      <h2>Associate patners </h2>
    </div>
    <div class="cols">
    <div class="card">
      <div class="card-images pic1"></div>
      <div class="sav">
      <h3>CHILDLINEINDIA:</h3><br>
      <p>With strong motivations and dedication to<br>
         make a child-friendly nation that guarantees <br>
         the rights and protection of all children.<br><a href="https://www.childlineindia.org/"><b>Source: childlineindia.org</b><p></a>
    </div></div>
    <div class="card">
      <div class="card-images pic2"></div>
      <div class="sav">
        <h3> PRATHAM:</h3><br>
      <p>The organization works towards identifying <br>
        the gaps in the education system and then <br>
        addressing them with cost-effective,<br>
         high-quality solutions and interventions. <br><a href="https://www.pratham.org/"><b>Source: pratham.org</b></a></p>
    </div></div>
    <div class="card">
      <div class="card-images pic3"></div>
      <div class="sav">
        <h3>UDAANWELFARE:</h3><br>
      <p>Giving wings to the hopes and <br>
        aspirations of underprivileged and <br>
        empowering them to a better tomorrow.<br><a href="https://www.udaanwelfare.org/"><b>Source: udaanwelfare.org</b></a></p>
    </div></div>
    <div class="card">
      <div class="card-images pic4"></div>
      <div class="sav">
        <h3>SHUDDHI</h3><br>
      <p>SHUDDHI™ is a registered NGO<br>
       ​working together with Partners &<br>
       ​Local Communities in India &<br>
​       Globally to improve Human Well-Being <br><a href="https://shuddhi.org/"><b>https://shuddhi.org/</b></a></p>
    </div></div>
    <div class="card">
      <div class="card-images pic5"></div>
      <div class="sav">
        <h3>MANAVKARTAVYA</h3><br>
      <p>Manav has the hands to perform <br>
        his kartavya by helping others.
        <br> Manav has the feet to perform his<br> kartavya by hastening to poor and needy. <br><a href="http://manavkartavya.org/women-empowerment/"><b>Source: manavkartavya</b></a></p>
    </div></div>
    <div class="card">
      <div class="card-images pic6"></div>
      <div class="sav">
        <h3>MANAVLOK</h3><br>
      <p>MANAVLOK aims to solve the socio-economic
        <br>problems of the community and to provide
        <br>a better life to them.<br><a href="http://manavlok.org/"><b>Source: manavlok</b></a></p>
    </div></div>
    <div class="card">
      <div class="card-images pic7"></div>
      <div class="sav">
        <h3>HELPAGEINDIA</h3><br>
      <p>HelpAge India is a leading charity platform
        <br>in India working with and for disadvantaged
        <br>elderly for more than 4 decades.<br> <a href="https://www.helpageindia.org/"><b>Source: helpageindia</b></a></p>
    </div></div>
    <div class="card">
      <div class="card-images pic8"></div>
      <div class="sav">
        <h3>DIGNITYFOUNDATION</h3><br>
      <p>A non-profit organisation that enables
        <br>senior citizens to lead active lives and
        <br>provides trusted information, productive
        <br>ageing opportunities and social support services.<br><a href="https://www.dignityfoundation.com/"><b>Source: dignityfoundation</b></a></p>
    </div>
  </div>
</div>
  </section>
     </body>
     </html>
